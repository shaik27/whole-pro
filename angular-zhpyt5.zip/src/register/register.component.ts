import { Component, OnInit } from '@angular/core';
import { Register } from '../register';
import { MyServiceService } from '../services/myservice.service';

@Component({
  selector: 'app-heroes',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent  {
  userDetails:Register;
  proName="shaik details";
  todayDate;
  countries:Array<any>;
  months:Array<any>;
  cars:Array<any>;
  constructor(private service:MyServiceService) {
    this.userDetails=new Register();
    this.todayDate=this.service.showTodayDate();
    this.userDetails=new Register;
    this.countries=this.service.getCountries();
    this.months=this.service.getMonths();
    this.cars=this.service.getCars();
    
  }
  registerUser(){
    console.log(this.userDetails);
  }
}
