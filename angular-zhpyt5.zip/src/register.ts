export class Register {
  firstName: string;
  lastName: string;
  password:any;
  gender:any;
  selectCars:any;
  country:any;
  month:string;
  agreeTerms:Boolean;
}